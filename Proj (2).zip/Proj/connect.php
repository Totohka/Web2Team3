<?php
    $conn = new mysqli("localhost", "u1846130_admin", "200982af_DP", "u1846130_shop");
?>