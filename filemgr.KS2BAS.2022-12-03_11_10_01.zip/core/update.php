<?php

$name = trim($_POST['name']);
$priceB = trim($_POST['priceBegin']);
$priceE = trim($_POST['priceEnd']);
$category = trim($_POST['category']);
$manufactor = trim($_POST['manufactor']);
//$stock = trim($_POST['stock']);
$id = trim($_POST['id']);

if ($name =='' OR $priceB=='' OR $priceE=='' OR $manufactor=='0' OR $category=='0'){
    echo 2;
    die;
}

// Create connection

$conn = new mysqli("localhost", "u1846130_admin", "200982af_DP", "u1846130_shop");
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$conn->set_charset("utf8mb4");
$sql = "UPDATE `product`
SET `name`='".$name."',
`categoryId`=".$category.",
`priceBegin`=".$priceB.",
`priceEnd`=".$priceE.",
`manufactorId`=".$manufactor."
WHERE `id`=".$id."";

if ($conn->query($sql) === TRUE){
    echo 1;
} else {
    echo "Error: " . $sql . "<br>" .  $conn->error;
}

$conn->close();
?>