<?php 
    $db = new PDO("mysql:host=localhost;dbname=u1846130_shop;charset=utf8mb4","u1846130_admin", "200982af_DP");
    $info = [];
    if ($query = $db->query(
        "SELECT `category`.`name` AS `categoryName`, 
            `category`.`description` AS `description`,
            `category`.`id` AS `categoryId`
        FROM `category`"
        )){
        $info = $query->fetchAll(PDO::FETCH_ASSOC);
    } else {
        print_r($db->errorInfo());
    }

    $infoc = [];
    if ($queryc = $db->query(
        "SELECT * FROM `category`"
        )){
        $infoc = $queryc->fetchAll(PDO::FETCH_ASSOC);
    } else {
        print_r($db->errorInfo());
    }
    $infom = [];
    if ($querym = $db->query(
        "SELECT * FROM `manufactor`"
        )){
        $infom = $querym->fetchAll(PDO::FETCH_ASSOC);
    } else {
        print_r($db->errorInfo());
    }
    $infos = [];
    if ($querys = $db->query(
        "SELECT * FROM `stock`"
        )){
        $infos = $querys->fetchAll(PDO::FETCH_ASSOC);
    } else {
        print_r($db->errorInfo());
    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
    <style type="text/css" media="all"> body { margin: 0; padding: 0;} </style>
    <button class = "newopen-popup">Добавить</button>
        <table border="1" cellspacing="0" cellpadding="0">
        <thead>
        <tr>
        <th><b>Номер</b></th>
        <th><b>Наименование</b></th>
        <th><b>Описание</b></th>
        </tr>
        </thead>
        <tbody>
            <?php foreach ($info as $data): ?>
            <tr>
            <td><?= $data['categoryId']; ?></td>
            <td><?= $data['categoryName']; ?></td>
            <td><?= $data['description'];?></td>
            <!-- <td><button class="open-popup" value="<?= $data['categoryId'];?>">Редактировать</button></td> -->
            </tr>
            <?php endforeach;?>
            <button onclick="window.location.href='https://team3bd.ru/cabinetadmin.html'">Назад</button>
            </tbody>
        </table>
    <style>
         .popup__bg, .newpopup__bg {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100vh;
        background: rgba(0,0,0,0.5);
        opacity: 0; 
        pointer-events: none; 
        transition: 0.5s all;
        }
        .popup__bg.active, .newpopup__bg.active { 
            opacity: 1; 
            pointer-events: all; 
            transition: 0.5s all;
        }
        .popup, .newpopup {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) scale(0); 
            background: #fff;
            width: 400px;
            padding: 25px;
            transition: 0.5s all;
        }
        .popup.active, .newpopup.active { 
            transform: translate(-50%, -50%) scale(1); 
            transition: 0.5s all;
        }
    </style>

    <div class="popup__bg"> 
        <form class="popup" method="POST">
            <label>Название:<input type="text" name="name" id="category-name" value="<?=$data['categoryName'];?>"/></label>
            <label>Описание:<input type="text" name="description" id="category-description" value="<?=$data['description'];?>"/></label>
            <button type="button" class="category-submit">Сохранить</button>
            <button type="button" class="close-popup">Закрыть</button>
        </form>
    </div> 
    
    <div class="newpopup__bg"> 
        <form class="newpopup" method="POST">
            <label>Название:<input type="text" name="name" id="newcategory-name"/></label>
            <label>Описание:<input type="text" name="description" id="newcategory-description"></label>
            <button type="button" class="newcategory-submit">Сохранить</button>
            <button type="button" class="newclose-popup">Закрыть</button>
        </form>
    </div> 
    
    <script src="../script/updateprod.js"></script>
    <script src="../script/newprod.js"></script>
    <script src="../script/ajax.js"></script>
</body>
</html>
