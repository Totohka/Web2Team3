<?php
        $db = new PDO("mysql:host=localhost;dbname=u1846130_shop;charset=utf8mb4","u1846130_admin", "200982af_DP");
        $info = [];
        if ($query = $db->query(
            "SELECT `stock`.`name` AS `stockName`,
                `stock`.`discount` AS `discount`,
                `stock`.`id` AS `stockId`
            FROM `stock`"
            )){
            $info = $query->fetchAll(PDO::FETCH_ASSOC);
        } else {
            print_r($db->errorInfo());
        }


?>
<!DOCTYPE html>
<html lang="en">
<body>
    
    <style type="text/css" media="all"> body { margin: 0; padding: 0;} </style>
        <table border="1" cellspacing="0" cellpadding="0">
        <thead>
        <tr>
        <th><b>Номер</b></th>
        <th><b>Наименование</b></th>
        <th><b>Скидка</b></th>
        </tr>
        </thead>
        <tbody>
            <?php foreach ($info as $data): ?>
            <tr>
            <td><?= $data['stockId']; ?></td>
            <td><?= $data['stockName']; ?></td>
            <td><?= $data['discount']; ?></td>
            <td><button class="open-popup" value="<?= $data['stockId'];?>">Редактировать</button></td>
            </tr>
            <?php endforeach;?>
            <button onclick="window.location.href = 'https://team3bd.ru/cabinetadmin.html'">Назад</button>
            </tbody>
        </table>
    <style>
         .popup__bg {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100vh;
        background: rgba(0,0,0,0.5);
        opacity: 0; 
        pointer-events: none; 
        transition: 0.5s all;
        }
        .popup__bg.active { 
            opacity: 1; 
            pointer-events: all; 
            transition: 0.5s all;
        }
        .popup {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) scale(0); 
            background: #fff;
            width: 400px;
            padding: 25px;
            transition: 0.5s all;
        }
        .popup.active { 
            transform: translate(-50%, -50%) scale(1); 
            transition: 0.5s all;
        }
    </style>
<!--     <div class="popup__bg"> 
        <form class="popup" method="POST">
            <input type="text" name="name" id="product-name" value="<?=$data['productName'];?>">
            <select name="category" id="product-category">
                <option value="0">Выберите категорию</option>
                <?
                foreach ($infoc as $datac):
                    ?>
                    <option value="<?=$datac['id']?>"><?=$datac['name']?></option>
                    <?
                endforeach;
                ?>
            </select>
            <input type="text" name="priceBegin" id="product-priceBegin" value="<?=$data['priceBegin'];?>">
            <select name="manufactor" id="product-manufactor">
                <option value="0">Выберите производителя</option>
                <?
                foreach ($infoc as $datac):
                    ?>
                    <option value="<?=$datac['id']?>"><?=$datac['name']?></option>
                    <?
                endforeach;
                ?>
            </select>
            <select name="stock" id="product-stock">
                <option value="0">Выберите акцию</option>
                <?
                foreach ($infoc as $datac):
                    ?>
                    <option value="<?=$datac['id']?>"><?=$datac['name']?></option>
                    <?
                endforeach;
                ?>
            </select>
            <input type="text" name="priceEnd" id="product-priceEnd" value="<?=$data['priceEnd'];?>">
            <input type="submit" id="product-submit">Сохранить</input>
            <button type="button" class="close-popup">Закрыть</button>
        </form>
    </div>  
    <button class="open-popup" >Редактировать</button>
 -->
    <script src="../script/updateprod.js"></script>
    <script src="../script/ajax.js"></script>
</body>
</html>