<?php

$name = trim($_POST['name']);
$pass = password_hash(trim($_POST['pass']), PASSWORD_BCRYPT,['cost'=>12]);
$email = trim($_POST['email']);

if ($name =='' OR $pass=='' OR $email==''){
    echo 2;
    die;
}

// Create connection
$conn = new mysqli("localhost", "u1846130_admin", "200982af_DP", "u1846130_username");
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "INSERT INTO `user` (`username`, `email`, `password`) VALUES ('".$name."', '".$email."', '".$pass."')";

if ($conn->query($sql) === TRUE) {
    echo 1;
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>