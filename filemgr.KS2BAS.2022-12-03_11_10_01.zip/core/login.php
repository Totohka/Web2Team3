<?php
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    //echo $password;
    if ($email == '' OR $password == ''){
        echo 2;
        die;
    }
    //create connection
    $conn = new mysqli("localhost", "u1846130_admin", "200982af_DP", "u1846130_username");
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    } 

    $sql = "SELECT `username`, `password` FROM `user` WHERE `email`='".$email."'"; // and `password`='".$password."'
    $result = $conn->query($sql);
    
    $user = [];
    
    if ($result->num_rows > 0) {
        // output data of each row
        if($row = $result->fetch_assoc()){
            $user = $row;
            if(password_verify($password , $user['password'])){
                echo "lets go my pig";
            }
            else{
                echo "0";
            }
            
        }
        
    } else {
        echo "0";
    }
    $conn->close();
?>