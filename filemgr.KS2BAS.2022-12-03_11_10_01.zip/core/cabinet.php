<?php 
    $db = new PDO("mysql:host=localhost;dbname=u1846130_shop;charset=utf8mb4","u1846130_admin", "200982af_DP");
    $info = [];
    if ($query = $db->query(
        "SELECT `product`.`name` AS `productName`, 
            `category`.`name` AS `categoryName`, 
            `priceEnd`, 
            `manufactor`.`name` AS `manufactorName`,
            `stockId`,
            `product`.`id` AS `productId`
        FROM `product` INNER JOIN `manufactor` ON `product`.`manufactorId` = `manufactor`.`id`
        INNER JOIN `category` ON `product`.`categoryId` = `category`.`id`"
        )){
        $info = $query->fetchAll(PDO::FETCH_ASSOC);
    } else {
        print_r($db->errorInfo());
    }

    $infoc = [];
    if ($queryc = $db->query(
        "SELECT * FROM `category`"
        )){
        $infoc = $queryc->fetchAll(PDO::FETCH_ASSOC);
    } else {
        print_r($db->errorInfo());
    }
    $infom = [];
    if ($querym = $db->query(
        "SELECT * FROM `manufactor`"
        )){
        $infom = $querym->fetchAll(PDO::FETCH_ASSOC);
    } else {
        print_r($db->errorInfo());
    }
    $infos = [];
    if ($querys = $db->query(
        "SELECT * FROM `stock`"
        )){
        $infos = $querys->fetchAll(PDO::FETCH_ASSOC);
    } else {
        print_r($db->errorInfo());
    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
    <style type="text/css" media="all"> body { margin: 0; padding: 0;} </style>
    <button class = "newopen-popup">Добавить</button>

    <button id="example_2_1" onclick="
    for(i=1;i<$data[`productId`];i++)
    if( document.getElementById(i).style.background == 'red'){
    document.getElementById(i).style.display='block'; 
    document.getElementById('example_2_1').style.display='none'; 
    document.getElementById('example_2_2').style.display='block';}" >Показать</button>

    <button id="example_2_2" onclick=" 
    for(i=1;i<$data[`productId`];i++)
    if( document.getElementById(i).style.background == 'red'){
    document.getElementById(i).style.display='none'; 
    document.getElementById('example_2_2').style.display='none'; 
    document.getElementById('example_2_1').style.display='block';}" style="display:none;">Скрыть</button>
        <table class="table_sort" border="1" cellspacing="0" cellpadding="0">
        <thead>
        <tr>
        <th><b>Номер</b></th>
        <th><b>Наименование</b></th>
        <th><b>Категория</b></th>
        <th><b>Цена</b></th>
        <th><b>Производитель</b></th>
        <th><b>Акция</b></th>
        </tr>
        </thead>
        <tbody>
            <?php foreach ($info as $data): ?>
            <tr id="<?= $data['productId'];?>">
            <td><?= $data['productId']; ?></td>
            <td><?= $data['productName']; ?></td>
            <td><?= $data['categoryName']; ?></td>
            <td><?= $data['priceEnd'];?>₽</td>
            <td><?= $data['manufactorName'];?></td>
            <td><?= $data['stockId'];?></td>
            <td><button class="open-popup" value="<?= $data['productId'];?>">Редактировать</button></td>
            <td><button class="deleteprod" value="<?= $data['productId'];?>">Удалить</button></td>
            </tr>
            <?php endforeach;?>
            <button onclick="window.location.href = 'https://team3bd.ru/cabinetadmin.html'">Назад</button>
            </tbody>
        </table>
    <style>
         .popup__bg, .newpopup__bg {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100vh;
        background: rgba(0,0,0,0.5);
        opacity: 0; 
        pointer-events: none; 
        transition: 0.5s all;
        }
        .popup__bg.active, .newpopup__bg.active { 
            opacity: 1; 
            pointer-events: all; 
            transition: 0.5s all;
        }
        .popup, .newpopup {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) scale(0); 
            background: #fff;
            width: 400px;
            padding: 25px;
            transition: 0.5s all;
        }
        .popup.active, .newpopup.active { 
            transform: translate(-50%, -50%) scale(1); 
            transition: 0.5s all;
        }
    </style>
 
    <div class="popup__bg"> 
        <form class="popup" method="POST">
            <input type="text" name="name" id="product-name" value="<?=$data['productName'];?>"/>
            <select name="category" id="product-category">
                <option value="0">Выберите категорию</option>
                <?
                foreach ($infoc as $datac):
                    ?>
                    <option value="<?=$datac['id']?>"><?=$datac['name']?></option>
                    <?
                endforeach;
                ?>
            </select>
            <input type="text" name="priceBegin" id="product-priceBegin" value="<?=$data['priceBegin'];?>"/>
            <select name="manufactor" id="product-manufactor">
                <option value="0">Выберите производителя</option>
                <?
                foreach ($infom as $datam):
                    ?>
                    <option value="<?=$datam['id']?>"><?=$datam['name']?></option>
                    <?
                endforeach;
                ?>
            </select>
            <select name="stock" id="product-stock">
                <option value="0">Выберите акцию</option>
                <?
                foreach ($infos as $datas):
                    ?>
                    <option value="<?=$datas['id']?>"><?=$datas['name']?></option>
                    <?
                endforeach;
                ?>
            </select>
            <input type="text" name="priceEnd" id="product-priceEnd" value="<?=$data['priceEnd'];?>"/>
            <button type="button" class="product-submit">Сохранить</button>
            <button type="button" class="close-popup">Закрыть</button>
        </form>
    </div> 
    
    <div class="newpopup__bg"> 
        <form class="newpopup" method="POST">
            <label>Название:<input type="text" name="name" id="newproduct-name"/></label>
            <select name="category" id="newproduct-category">
                <option value="0">Выберите категорию</option>
                <?
                foreach ($infoc as $datac):
                    ?>
                    <option value="<?=$datac['id']?>"><?=$datac['name']?></option>
                    <?
                endforeach;
                ?>
            </select>
            <label>Цена закупки:<input type="text" name="priceBegin" id="newproduct-priceBegin"?></label>
            <label>Количество:<input type="text" name="amount" id="newproduct-amount"?></label>
            <select name="manufactor" id="newproduct-manufactor">
                <option value="0">Выберите производителя</option>
                <?
                foreach ($infom as $datam):
                    ?>
                    <option value="<?=$datam['id']?>"><?=$datam['name']?></option>
                    <?
                endforeach;
                ?>
            </select>
            <label>Цена продажи:<input type="text" name="priceEnd" id="newproduct-priceEnd"?></label>
            <button type="button" class="newproduct-submit">Сохранить</button>
            <button type="button" class="newclose-popup">Закрыть</button>
        </form>
    </div> 
    <style>
    .table_sort table {
    border-collapse: collapse;
    }
    
    .table_sort th {
        color: #ffebcd;
        background: #008b8b;
        cursor: pointer;
    }
    
    .table_sort td,
    .table_sort th {
        width: 150px;
        height: 40px;
        text-align: center;
        border: 2px solid #846868;
    }
    
    .table_sort tbody tr:nth-child(even) {
        background: #e3e3e3;
    }
    
    th.sorted[data-order="1"],
    th.sorted[data-order="-1"] {
        position: relative;
    }
    
    th.sorted[data-order="1"]::after,
    th.sorted[data-order="-1"]::after {
        right: 8px;
        position: absolute;
    }
    
    th.sorted[data-order="-1"]::after {
    	content: "▼"
    }
    
    th.sorted[data-order="1"]::after {
    	content: "▲"
    }
    </style>
    
    <script src="../script/updateprod.js"></script>
    <script src="../script/deleteprod.js"></script>
    <script src="../script/newprod.js"></script>
    <script src="../script/ajax.js"></script>
    
</body>
</html>
