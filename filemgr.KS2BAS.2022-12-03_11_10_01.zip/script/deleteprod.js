let deleteButton = document.querySelector('.deleteprod'); 
deleteButton.addEventListener('click',() => { // Вешаем обработчик на крестик
   event.preventDefault();
   if(confirm("Вы уверены, что хотите удалить запись?")){
    if_id=document.getElementById(deleteButton.value);
    console.log(if_id);
    if_id.style.background = 'red';
   }
});