document.querySelector('#login-submit').onclick = function (event) {
    event.preventDefault();
    let password = document.querySelector('#login-password').value;
    let email = document.querySelector('#login-email').value;

    let data = {
        "password": password,
        "email": email
    }

    ajax('core/login.php', 'POST', login, data);


    function login(result) {
        console.log(result);
        if (result == 2) {
            alert('Заполните поля');
        }
        else if (result == 0) {
            alert('Пользователь не найден!');
        }
        else {
            console.log(result);
            window.location.href='https://team3bd.ru/cabinetadmin.html';
        }
    }
}