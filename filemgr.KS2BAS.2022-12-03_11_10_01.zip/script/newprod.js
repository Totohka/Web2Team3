let newpopupBg = document.querySelector('.newpopup__bg'); // Фон попап окна
let newpopup = document.querySelector('.newpopup'); // Само окно
let newopenPopupButtons = document.querySelectorAll('.newopen-popup'); // Кнопки для показа окна
let newclosePopupButton = document.querySelector('.newclose-popup'); // Кнопка для скрытия окна
let newButton = document.querySelector('.newproduct-submit');//кнопка обновить
newopenPopupButtons.forEach((button) => { // Перебираем все кнопки
    button.addEventListener('click', (e) => { // Для каждой вешаем обработчик событий на клик
        e.preventDefault(); // Предотвращаем дефолтное поведение браузера
        newpopupBg.classList.add('active'); // Добавляем класс 'active' для фона
        newpopup.classList.add('active'); // И для самого окна
        //newclosePopupButton.value = button.value;
        //console.log(newclosePopupButton.value);
        //document.querySelector('#product-submit').value = button.value;
        //document.querySelector('#product-name').value = button.value;
    })
});
newclosePopupButton.addEventListener('click',() => { // Вешаем обработчик на крестик
    newpopupBg.classList.remove('active'); // Убираем активный класс с фона
    newpopup.classList.remove('active'); // И с окна
});
document.addEventListener('click', (e) => { // Вешаем обработчик на весь документ
    if(e.target === newpopupBg) { // Если цель клика - фот, то:
        newpopupBg.classList.remove('active'); // Убираем активный класс с фона
        newpopup.classList.remove('active'); // И с окна
    }
});
newButton.addEventListener('click',() => { // Вешаем обработчик на крестик
    event.preventDefault();
    //alert("I'm alive");
    console.log("Hello!");
    let name = document.querySelector('#newproduct-name').value;
    let category = document.querySelector('#newproduct-category').value;
    let priceBegin = document.querySelector('#newproduct-priceBegin').value;
    let priceEnd = document.querySelector('#newproduct-priceEnd').value;
    let manufactor = document.querySelector('#newproduct-manufactor').value;
    let amount = document.querySelector('#newproduct-amount').value;
    //let stock = document.querySelector('#newproduct-stock').value;
    //let id = document.querySelector('#newproduct-id').value;
    let data = {
        "name":name,
        "category":category,
        "priceBegin":priceBegin,
        "priceEnd":priceEnd,
        "manufactor":manufactor,
        "amount":amount
        //"stock":stock,
        //"id":id
    }
    console.log("Work!");
    ajax('new.php', 'POST', login, data);
    

    function login(result) {
        console.log(result);
        if (result == 2) {
            alert('Заполните поля');
        }
        else if (result == 1) {
            alert('Успешно. Обновите страницу!');
        }
        else {
            alert('Ошибка, повторите позже!');
        }
    }
});
