document.querySelector('#signup-submit').onclick = function (event) {
    event.preventDefault();
    let name = document.querySelector('#signup-name').value;
    let pass = document.querySelector('#signup-pass').value;
    let email = document.querySelector('#signup-email').value;
    let data = {
        "name": name,
        "pass": pass,
        "email": email
    }

    ajax('core/signup.php', 'POST', login, data);

    function login(result) {
        console.log(result);
        if (result == 2) {
            alert('Заполните поля');
        }
        else if (result == 1) {
            alert('Успех. Теперь можно войти!');
            window.location.href='https://team3bd.ru/cabinetadmin.html'
        }
        else {
            alert('Ошибка, повторите регистрацию позже!');
        }
    }
}