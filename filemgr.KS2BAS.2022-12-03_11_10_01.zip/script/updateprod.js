let popupBg = document.querySelector('.popup__bg'); // Фон попап окна
let popup = document.querySelector('.popup'); // Само окно
let openPopupButtons = document.querySelectorAll('.open-popup'); // Кнопки для показа окна
let closePopupButton = document.querySelector('.close-popup'); // Кнопка для скрытия окна
let updateButton = document.querySelector('.product-submit');//кнопка обновить
openPopupButtons.forEach((button) => { // Перебираем все кнопки
    button.addEventListener('click', (e) => { // Для каждой вешаем обработчик событий на клик
        e.preventDefault(); // Предотвращаем дефолтное поведение браузера
        popupBg.classList.add('active'); // Добавляем класс 'active' для фона
        popup.classList.add('active'); // И для самого окна
        closePopupButton.value = button.value;
        console.log(closePopupButton.value);
        //document.querySelector('#product-submit').value = button.value;
        //document.querySelector('#product-name').value = button.value;
    })
});
closePopupButton.addEventListener('click',() => { // Вешаем обработчик на крестик
    popupBg.classList.remove('active'); // Убираем активный класс с фона
    popup.classList.remove('active'); // И с окна
});
document.addEventListener('click', (e) => { // Вешаем обработчик на весь документ
    if(e.target === popupBg) { // Если цель клика - фот, то:
        popupBg.classList.remove('active'); // Убираем активный класс с фона
        popup.classList.remove('active'); // И с окна
    }
});
updateButton.addEventListener('click',() => { // Вешаем обработчик на крестик
    event.preventDefault();
    //alert("I'm alive");
    console.log("Hello!");
    let name = document.querySelector('#product-name').value;
    let category = document.querySelector('#product-category').value;
    let priceBegin = document.querySelector('#product-priceBegin').value;
    let priceEnd = document.querySelector('#product-priceEnd').value;
    let manufactor = document.querySelector('#product-manufactor').value;
    //let stock = document.querySelector('#product-stock').value;
    let id = closePopupButton.value;
    let data = {
        "name":name,
        "category":category,
        "priceBegin":priceBegin,
        "priceEnd":priceEnd,
        "manufactor":manufactor,
        //"stock":stock,
        "id":id
    }
    console.log("Work!");
    ajax('update.php', 'POST', login, data);
    

    function login(result) {
        console.log(result);
        if (result == 2) {
            alert('Заполните поля');
        }
        else if (result == 1) {
            alert('Успешно. Обновите страницу!');
        }
        else {
            alert('Ошибка, повторите позже!');
        }
    }
});
document.addEventListener('DOMContentLoaded', () => {
    const getSort = ({ target }) => {
        const order = (target.dataset.order = -(target.dataset.order || -1));
        const index = [...target.parentNode.cells].indexOf(target);
        const collator = new Intl.Collator(['en', 'ru'], { numeric: true });
        const comparator = (index, order) => (a, b) => order * collator.compare(
            a.children[index].innerHTML,
            b.children[index].innerHTML
        );
        
        for(const tBody of target.closest('table').tBodies)
            tBody.append(...[...tBody.rows].sort(comparator(index, order)));

        for(const cell of target.parentNode.cells)
            cell.classList.toggle('sorted', cell === target);
    };
    
    document.querySelectorAll('.table_sort thead').forEach(tableTH => tableTH.addEventListener('click', () => getSort(event)));
    
});